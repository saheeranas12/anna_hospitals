
from flask import Flask, request,render_template
import psycopg2

CREATE_PATIENT = (
    "create table IF not exists patient_details  (p_id SERIAL PRIMARY KEY, name TEXT,age INT,sex TEXT,contact TEXT,address TEXT,I_id TEXT);"
)

INSERTVAL = (
    "insert into patient_details (name,age,sex,contact,address,I_id) values (%s,%s,%s,%s,%s,%s) returning p_id;"
    )

DISP_PATIENT=(
    "select * from patient_details where p_id=(%s);"


)

app= Flask(__name__)


connection = psycopg2.connect(host='localhost', dbname='patient_details', user='postgres', password='postgres', port=5432)

cursor=connection.cursor()



@app.route("/",methods=['GET','POST'])
def home():
    return render_template('home.html')

@app.route("/make",methods=['POST','GET'])
def make():
    return render_template('medhome.html')


@app.route("/create",methods=['POST','GET'])
def create():
    
    if request.method=='POST':
        
        name=request.form.get('Name')
        age=request.form.get('age')
        sex=request.form.get('sex')
        contact=request.form.get('contact')
        address=request.form.get('address')
        I_id=request.form.get('I_id')
        
        cursor.execute(CREATE_PATIENT)

        cursor.execute(INSERTVAL,(name,age,sex,contact,address,I_id))
        p_id = cursor.fetchone()[0]
        connection.commit()
        
    if name != None:

        return render_template('medhome.html',info=f"{p_id}:{name}'s record was created successfully ")
    # else:
    #     return render_template('medhome.html')

@app.route("/disp",methods=['POST','GET'])
def disp():
    return render_template('disp.html')

@app.route("/read",methods=['POST','GET'])
def read():

    
    p_id=request.form.get('p_id')
    cursor.execute(DISP_PATIENT,(p_id))
    records = cursor.fetchall()

    
    return render_template('disp.html',info=f"Patient id: {records[0][0]}, Name: {records[0][1]}, Age: {records[0][2]}, Sex: {records[0][3]}, Contact: {records[0][4]}, Address: {records[0][5]}, Inurance Id: {records[0][6]} ")

if __name__ =="__main__":
    app.run(port=5001,host="127.0.0.1",debug=True)

    